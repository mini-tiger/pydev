"""Deprecated module for BaseLanguageModel class, kept for backwards compatibility."""
from __future__ import annotations

from langchain.schema.language_model import BaseLanguageModel

__all__ = ["BaseLanguageModel"]
