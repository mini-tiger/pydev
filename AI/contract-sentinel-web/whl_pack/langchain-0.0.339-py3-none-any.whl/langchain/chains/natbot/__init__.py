"""Implement a GPT-3 driven browser.

Heavily influenced from https://github.com/nat/natbot
"""
